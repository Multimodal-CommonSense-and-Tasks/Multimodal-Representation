__author__ = 'max'

from flow_models.wolf.modules.discriminators.priors.prior import Prior, NormalPrior
from flow_models.wolf.modules.discriminators.priors.flow import FlowPrior
