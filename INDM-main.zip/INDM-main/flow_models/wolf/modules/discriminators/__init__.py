__author__ = 'max'

from flow_models.wolf.modules.discriminators.discriminator import Discriminator
from flow_models.wolf.modules.discriminators.gaussian import GaussianDiscriminator
from flow_models.wolf.modules.discriminators.categorical import CategoricalDiscriminator
from flow_models.wolf.modules.discriminators.priors import *
