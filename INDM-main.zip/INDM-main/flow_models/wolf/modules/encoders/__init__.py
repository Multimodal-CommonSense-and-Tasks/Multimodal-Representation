__author__ = 'max'

from flow_models.wolf.modules.encoders.encoder import Encoder
from flow_models.wolf.modules.encoders.global_encoder import GlobalResNetEncoderBatchNorm, GlobalResNetEncoderGroupNorm
from flow_models.wolf.modules.encoders.local_encoder import LocalResNetEncoderBatchNorm, LocalResNetEncoderGroupNorm
