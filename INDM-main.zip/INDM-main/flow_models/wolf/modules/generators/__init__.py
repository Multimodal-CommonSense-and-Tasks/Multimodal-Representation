__author__ = 'max'

from flow_models.wolf.modules.generators.generator import Generator
