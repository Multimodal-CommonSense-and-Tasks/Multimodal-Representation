__author__ = 'max'

from flow_models.wolf.wolf import WolfModel, WolfCore
